# WIP

This project is currently work in progress, meaning the majority of code and documentation is still to come. 

# Feature Requests

If you would like to request a specific feature to be added to fakebank you can do one of the following:
1. Fork the repo and write the code, if I like it I will reach out to you to see about setting up a pull request.
2. Submit an issue on this repo with the `feature request` label attached.
3. Reach out to me privately, that being said good luck as I wont publish contact info so you will need to do some digging. (This will impress me immensely if you can do it, and you will probably get a shout out somewhere.)
