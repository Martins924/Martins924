@if(isset($activeBank) && $activeBank != null)

@else
 <h1>Not Configured</h1>
@endif
