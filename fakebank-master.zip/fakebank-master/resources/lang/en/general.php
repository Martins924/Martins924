<?php

return [

    /**
     * General Translations to start with
     */

    'Name' => 'Name',
    'Caption' => 'Caption',
    'Active' => 'Active',
    'Not Configured' => 'Not Configured',
    'None Configured' => 'None Configured'
];
