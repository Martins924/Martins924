# fakebank

## inspiration
over the years, i have received thousands of spam calls, and recently i have sound kitboga's youtube and twitch. it has been wonderful to watch someone waste the scammers time as much as they waste ours. for that reason t am going to help work to improve some of the tools that can be used for wasting their time. 

## shout outs
- [https://github.com/mandeponium/UpDog-Credit-Union](mandeponium): thanks for making some of this public, i hate designing front ends but implementing logic is mainly what this project focuses on.
- [https://github.com/mathewsun/BankOfMontreal](matthewsun): thanks for making a template for bank of montreal that will be helpful.
- [https://www.twitch.tv/kitboga](kitboga): thanks for reporting these scams, wasting the scammers time and most of all having fun with it.

## techincal shout outs
- [https://github.com/spatie](spatie): thanks for designing a better activity log system than i ever could
